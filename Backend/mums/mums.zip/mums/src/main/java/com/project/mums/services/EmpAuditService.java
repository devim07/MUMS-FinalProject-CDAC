package com.project.mums.services;

import java.util.List;

import com.project.mums.payload.EmpAuditDto;

public interface EmpAuditService {

	List<EmpAuditDto> getAllEmpAudits();
}