package com.project.mums.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.mums.entities.Cust;

public interface CustRepo extends JpaRepository<Cust, Integer>{

}
