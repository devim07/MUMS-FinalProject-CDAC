package com.project.mums;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MumsApplicationTests {

	@Test
	void contextLoads() {
	}

}
